-- create database College_Management_System;

-- use College_Management_System;

CREATE TABLE Student (
    ROLL_NO varchar(10) PRIMARY KEY,
    ROOM_NO int,
	PASSWORD varchar(10),
    SNAME VARCHAR(50),
    DOB DATE,
    BRANCH VARCHAR(50),
    EMAIL_ID VARCHAR(50),
    SEMESTER INT,
    S_PNUMBER VARCHAR(15),
    FNAME VARCHAR(50),
    F_PNUMBER VARCHAR(15),
    STREET_ADDRESS VARCHAR(50),
    PIN_CODE VARCHAR(20),
    CITY VARCHAR(50),
    STATE VARCHAR(20)
);

INSERT INTO Student (ROLL_NO, ROOM_NO, PASSWORD, SNAME, DOB, BRANCH, EMAIL_ID, SEMESTER, S_PNUMBER, FNAME, F_PNUMBER, STREET_ADDRESS, PIN_CODE, CITY, STATE)
VALUES
("2201001", 001,"aB3pX8sZ", 'Amit Patel', '1995-02-15', 'Computer Science', 'amit.patel@example.com', 5, '9876543210', 'Rajesh Patel', '9876543211', '456 Oak St', '560022', 'Delhi', 'Delhi'),
("2201002", 002,"7dYx2fP1",'Neha Gupta', '1994-07-21', 'Electrical Engineering', 'neha.gupta@example.com', 6, '9876543212', 'Sunil Gupta', '9876543213', '456 Oak St', '560002', 'Delhi', 'Delhi'),
("2201003", 102,"kL9qA4wR",'Siddharth Sharma', '1996-04-03', 'Mechanical Engineering', 'siddharth.sharma@example.com', 4, '9876543214', 'Ramesh Sharma', '9876543215', '789 Pine St', '560003', 'Mumbai', 'Maharashtra'),
("2201004", 102,"3hJpC6lV",'Priya Singh', '1997-01-10', 'Civil Engineering', 'priya.singh@example.com', 3, '9876543216', 'Alok Singh', '9876543217', '987 Maple St', '560004', 'Kolkata', 'West Bengal'),
("2201005", 708,"tN2zU7mG",'Rajeev Verma', '1995-09-25', 'Chemical Engineering', 'rajeev.verma@example.com', 5, '9876543218', 'Vinod Verma', '9876543219', '654 Cedar St', '560005', 'Chennai', 'Tamil Nadu'),
("2201006", 345,"xH4eR9oQ",'Amit Patel', '1994-06-18', 'Computer Science', 'ayesha.khan@example.com', 6, '9876543220', 'Imran Khan', '9876543221', '321 Elm St', '560006', 'Bangalore', 'Karnataka'),
("2201007", 543,"1bT8yK6c",'Vikram Desai', '1996-03-07', 'Electronics Engineering', 'vikram.desai@example.com', 4, '9876543222', 'Satish Desai', '9876543223', '876 Birch St', '560007', 'Pune', 'Maharashtra'),
("2201008", 708,"5sW3vX2a",'Nisha Sharma', '1995-11-12', 'Computer Science', 'nisha.sharma@example.com', 5, '9876543224', 'Rajiv Sharma', '9876543225', '456 Oak St', '560022', 'Delhi', 'Delhi'),
("2201009", 001,"dG7nM4iL",'Arjun Reddy', '1994-08-30', 'Civil Engineering', 'arjun.reddy@example.com', 6, '9876543226', 'Rajendra Reddy', '9876543227', '789 Pine St', '560009', 'Chennai', 'Tamil Nadu'),
("2201010", 123,"9zO1rE6k",'Kavita Jain', '1996-05-05', 'Mechanical Engineering', 'kavita.jain@example.com', 4, '9876543228', 'Vivek Jain', '9876543229', '567 Oak St', '560010', 'Mumbai', 'Maharashtra'),
("2201011", 234,"rP3fY8xS",'Swati Gupta', '1997-02-18', 'Electrical Engineering', 'swati.gupta@example.com', 3, '9876543230', 'Suresh Gupta', '9876543231', '123 Maple St', '560011', 'Delhi', 'Delhi'),
("2201012", 123,"wV6mG2tL",'Kavita Jain', '1995-10-22', 'Computer Science', 'rohit.kumar@example.com', 5, '9876543232', 'Rajendra Kumar', '9876543233', '456 Pine St', '560012', 'Pune', 'Maharashtra'),
("2201013", 234,"Q7oU1aR9",'Shreya Singh', '1996-07-14', 'Chemical Engineering', 'shreya.singh@example.com', 4, '9876543234', 'Vijay Singh', '9876543235', '789 Elm St', '560013', 'Kolkata', 'West Bengal'),
("2201014", 002,"4cK5hV3q",'Karan Patel', '1994-04-01', 'Civil Engineering', 'karan.patel@example.com', 6, '9876543236', 'Sanjay Patel', '9876543237', '876 Cedar St', '560014', 'Chennai', 'Tamil Nadu'),
("2201015", 345,"8jS2lI9n",'Neha Reddy', '1996-11-26', 'Electronics Engineering', 'neha.reddy@example.com', 3, '9876543238', 'Ravi Reddy', '9876543239', '234 Oak St', '560015', 'Bangalore', 'Karnataka'),
("2201016", 543,"uA6eZ4wX",'Siddharth Sharma', '1995-08-18', 'Mechanical Engineering', 'vivek.deshmukh@example.com', 5, '9876543240', 'Aniket Deshmukh', '9876543241', '567 Pine St', '560016', 'Hyderabad', 'Telangana'),
("2201017", 100,"oQ1rT5mN",'Sneha Jain', '1997-05-10', 'Computer Science', 'sneha.jain@example.com', 4, '9876543242', 'Rahul Jain', '9876543243', '876 Elm St', '560017', 'Mumbai', 'Maharashtra'),
("2201018", 200,"2vX7bW3s",'Amita Verma', '1995-02-14', 'Electrical Engineering', 'amita.verma@example.com', 6, '9876543244', 'Suresh Verma', '9876543245', '567 Oak St', '560030', 'Mumbai', 'Maharashtra'),
("2201019", 300,"6iL9cJ8h",'Kavita Jain', '1994-09-30', 'Mechanical Engineering', 'rajat.sharma@example.com', 3, '9876543246', 'Vivek Jain', '9876543247', '567 Oak St', '560019', 'Pune', 'Maharashtra'),
("2201020", 100,"zK3xV4sP",'Anita Singh', '1996-06-05', 'Chemical Engineering', 'anita.singh@example.com', 5, '9876543248', 'Vinay Singh', '9876543249', '321 Cedar St', '560020', 'Kolkata', 'West Bengal'),
("2201021", 200,"gS5nU1qH",'Rahul Kumar', '1995-03-12', 'Computer Science', 'rahul.kumar@example.com', 5, '9876543250', 'Amit Kumar', '9876543251', '123 Main St', '560021', 'Ahmedabad', 'Gujarat'),
("2201022", 300,"8mW2jX7p",'Pooja Sharma', '1994-08-21', 'Electrical Engineering', 'pooja.sharma@example.com', 6, '9876543252', 'Anil Sharma', '9876543253', '456 Oak St', '560022', 'Delhi', 'Delhi'),
("2201023", 456,"1aR9oQ3k",'Ananya Singh', '1996-05-03', 'Mechanical Engineering', 'ananya.singh@example.com', 4, '9876543254', 'Rajesh Singh', '9876543255', '789 Pine St', '560023', 'Mumbai', 'Maharashtra'),
("2201024", 456,"bT4yK6lC",'Priya Singh', '1997-01-10', 'Civil Engineering', 'priya.singh@example.com', 3, '9876543256', 'Alok Singh', '9876543257', '987 Maple St', '560024', 'Kolkata', 'West Bengal'),
("2201025", 234,"dU2mG7nV",'Rajeev Verma', '1995-09-25', 'Chemical Engineering', 'rajeev.verma@example.com', 5, '9876543258', 'Vinod Verma', '9876543259', '567 Oak St', '560030', 'Mumbai', 'Maharashtra'),
("2201026", 152,"3zO1rE8k",'Ayesha Khan', '1994-06-18', 'Computer Science', 'ayesha.khan@example.com', 6, '9876543260', 'Imran Khan', '9876543261', '321 Elm St', '560026', 'Bangalore', 'Karnataka'),
("2201027", 152,"hP5fY9xS",'Sneha Jain', '1996-03-07', 'Electronics Engineering', 'vikram.desai@example.com', 4, '9876543262', 'Satish Desai', '9876543263', '876 Birch St', '560027', 'Pune', 'Maharashtra'),
("2201028", 673,"jH7eR4wL",'Nisha Sharma', '1995-11-12', 'Computer Science', 'nisha.sharma@example.com', 5, '9876543264', 'Rajiv Sharma', '9876543265', '234 Cedar St', '560028', 'Hyderabad', 'Telangana'),
("2201029", 326,"6sW3vX2a",'Arjun Reddy', '1994-08-30', 'Civil Engineering', 'arjun.reddy@example.com', 6, '9876543266', 'Rajendra Reddy', '9876543267', '789 Pine St', '560029', 'Chennai', 'Tamil Nadu'),
("2201030", 326,"9cK8hV5q",'Kavita Jain', '1996-05-05', 'Mechanical Engineering', 'kavita.jain@example.com', 4, '9876543268', 'Vivek Jain', '9876543269', '567 Oak St', '560030', 'Mumbai', 'Maharashtra');

CREATE TABLE DEPARTMENT (
    DID INT PRIMARY KEY,
    DNAME VARCHAR(50),
    BUILDING VARCHAR(50),
    BUDGET NUMERIC(8,2)
);

INSERT INTO DEPARTMENT (DID, DNAME, BUILDING, BUDGET)
VALUES
(101, 'Computer Science', 'Jones Hall', 500000.00),
(105, 'Electrical Engineering', 'Smith Building', 450000.50),
(106, 'Mechanical Engineering', 'Engineering Center', 600000.75),
(104, 'Mathematics', 'Newton Hall', 300000.25),
(109, 'Civil', 'Einstein Building', 400000.50),
(107, 'Chemical Engineering','Jones Hall', 300000.40);

CREATE TABLE Faculty (
    F_ID varchar(20) PRIMARY KEY,
    PASSWORD varchar(10),
    FAC_NAME VARCHAR(50),
    EMAIL_ID VARCHAR(30),
    FAC_ROOM_NO INT,
    DID int,
    foreign key(DID) references DEPARTMENT(DID)
);

INSERT INTO Faculty (F_ID, PASSWORD, FAC_NAME, EMAIL_ID, FAC_ROOM_NO, DID)
VALUES
("1","A2bC4dE6" ,'Sumit Mishra', 'sumit.mishra@example.com', 201, 101),
("2","X8yZ0wP2" ,'Prof. Sneha Kapoor', 'sneha.kapoor@example.com', 202, 105),
("3","Q1rS3tU5" ,'Dr. Rajesh Verma', 'rajesh.verma@example.com', 203, 106),
("4","H7iJ9kL1" ,'Prof. Preeti Desai', 'neha.singh@example.com', 204, 109),
("5","M4nO6pQ8" ,'Dr. Anil Desai', 'anil.desai@example.com', 205, 107),
("6","Y2zX4aB6" ,'Prof. Kavita Jain', 'kavita.jain@example.com', 206, 101),
("7","C8dE0fG2" ,'Dr. Vivek Reddy', 'vivek.reddy@example.com', 207, 105),
("8","I3jK5lM7" ,'Prof. Swati Gupta', 'swati.gupta@example.com', 208, 101),
("9","U9vW1xY3" ,'Dr. Rohit Kumar', 'rohit.kumar@example.com', 209, 105),
("10","R4sT6uI8" ,'Prof. Anita Singh', 'anita.singh@example.com', 210, 106),
("11","Z2yX4wP6" ,'Dr. Vikram Deshmukh', 'vikram.deshmukh@example.com', 211, 105),
("12","Q8rS0tU2" ,'Prof. Nisha Sharma', 'nisha.sharma@example.com', 212, 101),
("13","L1mN3oP5" ,'Dr. Rohit Kumar', 'amit.patel@example.com', 213, 106),
("14","F7gH9iJ1" ,'Prof. Priya Singh', 'priya.singh@example.com', 214, 109),
("15","V4wX6yZ8" ,'Prof. Meera Kapoor', 'arjun.reddy@example.com', 215, 107),
("16","D2eF4gH6" ,'Prof. Kritika Verma', 'kritika.verma@example.com', 216, 105),
("17","O8pQ0rS2" ,'Dr. Sanjay Gupta', 'sanjay.gupta@example.com', 217, 101),
("18","K5lM7nO9" ,'Prof. Meera Kapoor', 'meera.kapoor@example.com', 218, 106),
("19","A1bC3dE5" ,'Dr. Rajat Sharma', 'rajat.sharma@example.com', 219, 109),
("20","J9kL1mN3" ,'Prof. Preeti Desai', 'preeti.desai@example.com', 220, 107),
("21","ap23fp14" ,'Anuradha Jha', 'anuradha.jha@example.com', 501, 104);

CREATE TABLE BOOK (
    BOOK_ID INT PRIMARY KEY,
    TITLE VARCHAR(50),
    AUTHOR VARCHAR(50),
    BOOK_COUNT INT
);

INSERT INTO BOOK (BOOK_ID, TITLE, AUTHOR,  BOOK_COUNT)
VALUES
(100, 'The Great Gatsby', 'F. Scott Fitzgerald',  5),
(101, 'To Kill a Mockingbird', 'Harper Lee',  3),
(102, '1984', 'George Orwell',  8),
(103, 'Pride and Prejudice', 'Jane Austen',  6),
(104, 'The Catcher in the Rye', 'J.D. Salinger',  4),
(105, 'The Hobbit', 'J.R.R. Tolkien',  7),
(106, 'Brave New World', 'Aldous Huxley', 5),
(107, 'The Lord of the Rings', 'J.R.R. Tolkien', 10),
(108, 'The Alchemist', 'Paulo Coelho',  3),
(109, 'Harry Potter and the Sorcerer\'s Stone', 'J.K. Rowling', 6),
(110, 'The Da Vinci Code', 'Dan Brown',  8),
(111, 'The Chronicles of Narnia', 'C.S. Lewis',  5),
(112, 'The Great Expectations', 'Charles Dickens',  7),
(113, 'The Shawshank Redemption', 'Stephen King',  4),
(114, 'The Girl with the Dragon Tattoo', 'Stieg Larsson',  6),
(115, 'The Road', 'Cormac McCarthy',  3),
(116, 'The Hitchhiker\'s Guide to the Galaxy', 'Douglas Adams', 9),
(117, 'The Kite Runner', 'Khaled Hosseini',  5),
(118, 'The War of the Worlds', 'H.G. Wells', 7),
(119, 'The Art of War', 'Sun Tzu', 10),
(120, 'The Metamorphosis', 'Franz Kafka',  6),
(121, 'One Hundred Years of Solitude', 'Gabriel García Márquez',  8),
(122, 'The Picture of Dorian Gray', 'Oscar Wilde',  4),
(123, 'The Grapes of Wrath', 'John Steinbeck', 5),
(124, 'Moby-Dick', 'Herman Melville',  7),
(125, 'The Odyssey', 'Homer',  9),
(126, 'Crime and Punishment', 'Fyodor Dostoevsky',  5),
(127, 'Lord of the Flies', 'William Golding',  6),
(128, 'The Three Musketeers', 'Alexandre Dumas',  8),
(129, 'The Count of Monte Cristo', 'Alexandre Dumas',  7);

CREATE TABLE course (
    C_ID INT PRIMARY KEY,
    CNAME VARCHAR(50),
    CREDIT INT,
    DID INT,
    SEMESTER int,
    foreign key(DID) references DEPARTMENT(DID)
);

INSERT INTO course (C_ID, CNAME, CREDIT, DID, SEMESTER)
VALUES
(1, 'Introduction to Programming', 4, 101, 1),
(2, 'Database Management Systems', 3, 101, 2),
(3, 'Computer Networks', 4, 101, 4),
(4, 'Software Engineering', 3, 101, 6),
(5, 'Linear Algebra', 3, 104, 7),
(6, 'Digital Electronics', 3, 105, 3),
(7, 'Operating Systems', 4, 101, 8),
(9, 'Machine Learning', 4, 101, 5),
(10, 'Algorithms and Data Structures', 4, 101, 1),
(11, 'Computer Architecture', 4, 101, 5),
(12, 'Artificial Intelligence', 4, 101, 1),
(14, 'Discrete Mathematics', 3, 104, 7),
(15, 'Network Security', 4, 101, 2),
(16, 'Database Design', 3, 101, 7),
(21, 'Thermodynamics', 4, 106, 3),
(22, 'Fluid Mechanics', 3, 106, 5),
(23, 'Strength of Materials', 4, 106, 4),
(24, 'Machine Design', 3, 106, 2),
(25, 'Automobile Engineering', 4, 106, 6),
(26, 'Chemical Reaction Engineering', 4, 107, 2),
(27, 'Process Control', 3, 107, 8),
(28, 'Heat Transfer in Chemical Processes', 4, 107, 6),
(29, 'Polymer Chemistry', 3, 107, 2),
(30, 'Environmental Engineering', 4, 107, 7),
(31, 'Electric Circuits', 4, 105, 8),
(32, 'Power Systems', 3, 105, 5),
(33, 'Control Systems', 4, 105, 2),
(34, 'Digital Signal Processing', 3, 105, 1),
(36, 'Structural Analysis', 4, 109, 2),
(37, 'Geotechnical Engineering', 3, 109, 5),
(38, 'Construction Management', 4, 109, 5),
(39, 'Hydraulic Engineering', 3, 109, 2),
(40, 'Environmental Engineering', 4, 109, 2);

CREATE TABLE ISSUE (
    ISSUE_ID VARCHAR(10) PRIMARY KEY,
    ROLL_NO varchar(10),
    BOOK_ID int,
    ISSUE_DATE DATE,
    RETURN_DATE DATE,
    STATUS VARCHAR(20),
    FINE INT,
    foreign key(ROLL_NO) references STUDENT(ROLL_NO),
    foreign key(BOOK_ID) references BOOK(BOOK_ID)
);

INSERT INTO ISSUE (ISSUE_ID, ROLL_NO, BOOK_ID, ISSUE_DATE, RETURN_DATE, STATUS, FINE)
VALUES
('A123', "2201018", 100, '2024-03-01', '2024-04-15', 'Returned', 10),
('B456', "2201012", 101, '2024-03-02', '2024-04-16', 'Not Returned', 10),
('C789', "2201019", 101, '2024-03-03', '2024-04-17', 'Returned', 0),
('D012', "2201020", 102, '2024-01-04', '2024-02-18', 'Not Returned', 15),
('E345', "2201020", 103, '2024-01-05', '2024-02-19', 'Returned', 0),
('F678', "2201021", 104, '2024-03-06', '2024-05-20', 'Not Returned', 20),
('G901', "2201018", 104, '2024-03-07', '2024-04-21', 'Returned', 0),
('H234', "2201009", 125, '2024-03-08', '2024-05-22', 'Not Returned', 25),
('I567', "2201002", 102, '2024-03-09', '2024-03-23', 'Returned', 70),
('J890', "2201012", 102, '2024-03-10', '2024-04-24', 'Not Returned', 30);

create table MESS_COMPLAIN_TYPE(
	COMPLAIN_ID varchar(10) primary key,
    COMPLAIN varchar(100)
);

INSERT INTO MESS_COMPLAIN_TYPE (COMPLAIN_ID, COMPLAIN)
VALUES
('C001', 'Food issue'),
('C002', 'Hygein'),
('C003', 'Unclean plates'),
('C004', 'Staff behaviour'),
('C005', 'Overcrowding'),
('C006', 'Other');

create table MAKES_MESS(
	COMPLAIN_ID varchar(20),
    DESCRIPTION varchar(100),
    ROLL_NO varchar(10),
    COMPLAIN_DATE date,
    STATUS varchar(20),
    primary key(COMPLAIN_ID,ROLL_NO),
    foreign key(COMPLAIN_ID) references MESS_COMPLAIN_TYPE(COMPLAIN_ID),
    foreign key(ROLL_NO) references STUDENT(ROLL_NO)
);

INSERT INTO MAKES_MESS(COMPLAIN_ID, DESCRIPTION, ROLL_NO, COMPLAIN_DATE, STATUS)
VALUES
('C001', 'Rooti is not satisfactory.', "2201010", '2024-02-01', "resolved"),
('C002', 'Tables are dirty', "2201019", '2024-02-02', "unresolved"),
('C003', 'Plates are cleaned properly', "2201023", '2024-02-03',"resolved"),
('C004', 'Staffs do not serve food properly', "2201010", '2024-02-04',"resolved"),
('C001', 'Too much oil in puri', "2201011", '2024-02-05',"resolved"),
('C005', 'Less numbers of chairs', "2201005", '2024-02-20',"unresolved");

CREATE TABLE TEACHES (
    F_ID varchar(20),
    C_ID INT,
    PRIMARY KEY (F_ID, C_ID),
    FOREIGN KEY (F_ID) REFERENCES faculty(F_ID),
    FOREIGN KEY (C_ID) REFERENCES course(C_ID)
);

INSERT INTO TEACHES (F_ID, C_ID)
VALUES
("1", 1),  -- Sumit Mishra teaches Introduction to Programming
("1", 2),  -- Sumit Mishra teaches Database Management Systems
("2", 5),  -- Prof. Sneha Kapoor teaches Linear Algebra
("2", 6),  -- Prof. Sneha Kapoor teaches Digital Electronics
("3", 9),  -- Dr. Rajesh Verma teaches Machine Learning
("3", 10), -- Dr. Rajesh Verma teaches Algorithms and Data Structures
("4", 14), -- Prof. Preeti Desai teaches Discrete Mathematics
("4", 16), -- Prof. Preeti Desai teaches Database Design
("5", 21), -- Dr. Anil Desai teaches Thermodynamics
("5", 22), -- Dr. Anil Desai teaches Fluid Mechanics
("6", 11),  -- Prof. Kavita Jain teaches Computer Architecture
("7", 15),  -- Dr. Vivek Reddy teaches Network Security
("8", 12),  -- Prof. Swati Gupta teaches Artificial Intelligence
("9", 33),  -- Dr. Rohit Kumar teaches Control Systems
("10", 26), -- Prof. Anita Singh teaches Chemical Reaction Engineering
("11", 32), -- Dr. Vikram Deshmukh teaches Power Systems
("12", 30), -- Prof. Nisha Sharma teaches Environmental Engineering
("13", 31), -- Dr. Rohit Kumar teaches Electric Circuits
("14", 36), -- Prof. Priya Singh teaches Structural Analysis
("15", 37), -- Prof. Meera Kapoor teaches Geotechnical Engineering
("16", 34), -- Prof. Kritika Verma teaches Digital Signal Processing
("17", 39), -- Dr. Sanjay Gupta teaches Hydraulic Engineering
("18", 40), -- Prof. Meera Kapoor teaches Environmental Engineering
("19", 2),  -- Dr. Rajat Sharma teaches Database Management Systems
("20", 4),  -- Prof. Preeti Desai teaches Operating Systems
("21", 3),  -- Anuradha Jha teaches Computer Networks
("1", 24),  -- Sumit Mishra teaches Machine Design
("2", 28),  -- Prof. Sneha Kapoor teaches Heat Transfer in Chemical Processes
("3", 23),  -- Dr. Rajesh Verma teaches Strength of Materials
("4", 7);   -- Prof. Preeti Desai teaches Operating Systems

create table HOSTEL_COMPLAIN_TYPE(
	COMPLAIN_ID varchar(10) primary key,
    COMPLAIN varchar(100)
);

INSERT INTO HOSTEL_COMPLAIN_TYPE (COMPLAIN_ID, COMPLAIN)
VALUES
('H001', 'Electrical appliances issue'),
('H002', 'Clineaness'),
('H003', 'Wi-Fi'),
('H004', 'Furniture'),
('H005', 'Medicine issue'),
('H006', 'Other');


create table MAKES_HOSTEL(
	COMPLAIN_ID varchar(20),
    DESCRIPTION varchar(100),
    ROLL_NO varchar(10),
    COMPLAIN_DATE date,
    STATUS varchar(20),
    primary key(COMPLAIN_ID,ROLL_NO),
    foreign key(COMPLAIN_ID) references HOSTEL_COMPLAIN_TYPE(COMPLAIN_ID),
    foreign key(ROLL_NO) references STUDENT(ROLL_NO)
);

INSERT INTO MAKES_HOSTEL (COMPLAIN_ID,DESCRIPTION, ROLL_NO, COMPLAIN_DATE, STATUS)
VALUES 
    ('H001', 'Fan not working', "2201001", '2024-03-06', "resolved" ),
    ('H002', 'Room not cleaned since a month', "2201001", '2024-03-07',"unresolved"),
    ('H003', 'Speed is very slow on 3rd floor', "2201002", '2024-03-08','unresolved'),
    ('H004', 'Table is broken', "2201002", '2024-03-09','resolved'),
    ('H006', 'Security guards are sleeping at night', "2201003", '2024-03-10','unresolved'),
    ('H006', 'Dirty water in washroom', "2201004", '2024-03-11','resolved');
    
CREATE TABLE TAKES (
    ROLL_NO varchar(10),
    C_ID INT,
    PRIMARY KEY (ROLL_NO, C_ID),
    FOREIGN KEY (ROLL_NO) REFERENCES STUDENT(ROLL_NO),
    FOREIGN KEY (C_ID) REFERENCES COURSE(C_ID)
);

INSERT INTO takes (ROLL_NO, C_ID)
VALUES
    ("2201001", 1),
    ("2201001", 2),
    ("2201002", 1),
    ("2201002", 3),
    ("2201003", 2),
    ("2201003", 3),
    ("2201004", 1),
    ("2201005", 3),
    ("2201006", 2),
    ("2201006", 3),
    ("2201007", 1),
    ("2201007", 2),
    ("2201008", 3),
    ("2201008", 4),
    ("2201009", 2),
    ("2201009", 4),
    ("2201010", 1),
    ("2201010", 3),
    ("2201011", 2),
    ("2201011", 4);
    
CREATE TABLE AMBULANCE_DETAIL (
    AMB_ID VARCHAR(10) PRIMARY KEY,
    ROLL_NO varchar(10),
    REASON VARCHAR(100),
    DATE DATETIME,
    FOREIGN KEY (ROLL_NO) REFERENCES STUDENT (ROLL_NO)
);

INSERT INTO AMBULANCE_DETAIL (AMB_ID, ROLL_NO, REASON, DATE)
VALUES
    ('A001', "2201001", 'Medical checkup', '2024-03-06 08:30:00'),
    ('A002', "2201002", 'Injury', '2024-03-07 10:45:00'),
    ('A003', "2201003", 'Illness', '2024-03-08 12:15:00'),
    ('A004', "2201004", 'Allergic reaction', '2024-03-09 14:20:00'),
    ('A005', "2201005", 'Medical appointment', '2024-03-10 16:30:00'),
    ('A006', "2201001", 'Fever', '2024-03-11 18:45:00'),
    ('A007', "2201002", 'Accident', '2024-03-12 20:00:00'),
    ('A008', "2201003", 'Emergency', '2024-03-13 22:10:00'),
    ('A009', "2201004", 'Breathing difficulties', '2024-03-14 23:30:00'),
    ('A010', "2201005", 'Infection', '2024-03-15 01:45:00'),
    ('A011', "2201006", 'Injury', '2024-03-16 03:00:00'),
    ('A012', "2201007", 'Illness', '2024-03-17 05:15:00'),
    ('A013', "2201008", 'Allergic reaction', '2024-03-18 07:30:00'),
    ('A014', "2201009", 'Medical appointment', '2024-03-19 09:45:00'),
    ('A015', "2201010", 'Fever', '2024-03-20 12:00:00'),
    ('A016', "2201006", 'Accident', '2024-03-21 14:15:00');
    
CREATE TABLE GATE_ENTRY (
	ROLL_NO VARCHAR(10),
	ENTRY_TIME DATETIME
);  

INSERT INTO GATE_ENTRY (roll_no, entry_time) 
VALUES
('2201001', '2024-01-01 08:00:00'),
('2201002', '2024-01-15 08:15:00'),
('2201003', '2024-01-29 08:30:00'),
('2201004', '2024-02-12 08:45:00'),
('2201005', '2024-02-26 09:00:00'),
('2201006', '2024-03-10 09:15:00'),
('2201007', '2024-03-14 09:30:00'),
('2201008', '2024-03-18 09:45:00'),
('2201009', '2024-03-22 10:00:00'),
('2201010', '2024-03-31 10:15:00');

create table ATTENDANCE(
	ROLL_NO varchar(10),
    C_ID int,
    TIME datetime,
    primary key(ROLL_NO,TIME)
);

create table study_form(
	ROLL_NO varchar(10),
    F_ID varchar(10),
    primary key(ROLL_NO,F_ID),
    foreign key(ROLL_NO) references student(ROLL_NO),
    foreign key(F_ID) references faculty(F_ID)
);